function calculateSleep() {
    let hours = parseInt(document.getElementById("hours").value);
    let screen = parseInt(document.getElementById("screen").value);
    let caffeine = parseInt(document.getElementById("caffeine").value);
    let mood = parseInt(document.getElementById("mood").value);

    let score = 0;

    if (hours >= 7 && hours <= 9) score += 40;
    else if (hours >= 5) score += 20;
    else score += 5;

    if (screen < 1) score += 30;
    else if (screen <= 2) score += 15;
    else score += 5;

    if (caffeine == 0) score += 20;
    else if (caffeine <= 2) score += 10;
    else score += 3;

    score += mood * 5;

    let message = "";

    if (score >= 80) {
        message = "Excellent sleep! 😴✨ Keep it up!";
    } else if (score >= 60) {
        message = "Pretty good sleep 🙂 Try reducing screen time!";
    } else if (score >= 40) {
        message = "Average sleep 😕 Improve your habits.";
    } else {
        message = "Poor sleep 😣 Try sleeping early and reducing caffeine.";
    }

    let resultBox = document.getElementById("result");
    resultBox.style.display = "block";
    resultBox.innerHTML = `
        <b>Your Sleep Score: ${score}/100</b><br><br>
        ${message}
    `;
}
